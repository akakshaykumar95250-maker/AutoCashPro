import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { userId } = req.body;

      // Get user data
      const { data: user, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (userError || !user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if 24 hours have passed since last sync
      const lastSync = new Date(user.last_sync_time);
      const now = new Date();
      const hoursSinceSync = (now - lastSync) / (1000 * 60 * 60);

      if (hoursSinceSync < 24) {
        const hoursRemaining = Math.ceil(24 - hoursSinceSync);
        return res.status(200).json({
          canSync: false,
          message: `Wait ${hoursRemaining} hours before next sync`,
          hoursRemaining,
          lockedBalance: user.locked_balance,
          mainWallet: user.main_wallet
        });
      }

      // Calculate 40% profit share
      const eligibleBalance = user.locked_balance;
      const transferAmount = Math.floor(eligibleBalance * 0.40);
      const remainingLocked = eligibleBalance - transferAmount;

      if (transferAmount <= 0) {
        return res.status(200).json({
          canSync: true,
          message: 'No eligible balance to transfer',
          transferred: 0,
          lockedBalance: user.locked_balance,
          mainWallet: user.main_wallet
        });
      }

      // Update balances
      const { data: updatedUser, error: updateError } = await supabase
        .from('users')
        .update({
          locked_balance: remainingLocked,
          main_wallet: user.main_wallet + transferAmount,
          last_sync_time: new Date().toISOString()
        })
        .eq('id', userId)
        .select()
        .single();

      if (updateError) throw updateError;

      // Record transaction
      await supabase.from('transactions').insert({
        user_id: userId,
        type: 'sync',
        amount: transferAmount,
        from_balance: 'locked',
        to_balance: 'main',
        description: `Revenue sync - 40% transferred (${transferAmount} coins)`,
        created_at: new Date().toISOString()
      });

      return res.status(200).json({
        canSync: true,
        success: true,
        transferred: transferAmount,
        lockedBalance: updatedUser.locked_balance,
        mainWallet: updatedUser.main_wallet,
        inrValue: (updatedUser.main_wallet / 1000).toFixed(2),
        message: `Successfully transferred ${transferAmount} coins to main wallet!`
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Sync API error:', err);
    res.status(500).json({ error: err.message });
  }
}