import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { userId, amount, upiId } = req.body;

      // Get user data
      const { data: user, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (userError || !user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check minimum withdrawal (1000 coins = ₹1)
      if (amount < 1000) {
        return res.status(400).json({ error: 'Minimum withdrawal is 1000 coins (₹1)' });
      }

      // Check balance
      if (user.main_wallet < amount) {
        return res.status(400).json({ error: 'Insufficient balance in main wallet' });
      }

      // Deduct from main wallet
      const { data: updatedUser, error: updateError } = await supabase
        .from('users')
        .update({
          main_wallet: user.main_wallet - amount
        })
        .eq('id', userId)
        .select()
        .single();

      if (updateError) throw updateError;

      // Record transaction
      await supabase.from('transactions').insert({
        user_id: userId,
        type: 'withdrawal',
        amount: amount,
        from_balance: 'main',
        to_balance: null,
        description: `Withdrawal request - ${amount} coins to UPI: ${upiId}`,
        created_at: new Date().toISOString()
      });

      return res.status(200).json({
        success: true,
        amount,
        inrValue: (amount / 1000).toFixed(2),
        upiId,
        newBalance: updatedUser.main_wallet,
        message: `Withdrawal request of ₹${(amount / 1000).toFixed(2)} submitted successfully!`
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Withdraw API error:', err);
    res.status(500).json({ error: err.message });
  }
}