import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { secretKey, action, userId, ...data } = req.body;

      // Verify admin secret
      if (secretKey !== 'CYBER2077') {
        return res.status(401).json({ error: 'Invalid admin key' });
      }

      if (action === 'verify') {
        return res.status(200).json({ verified: true });
      }

      if (action === 'getUsers') {
        const { data: users, error } = await supabase
          .from('users')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(50);

        if (error) throw error;
        return res.status(200).json(users);
      }

      if (action === 'blockUser') {
        const { data: user, error } = await supabase
          .from('users')
          .update({ is_blocked: true })
          .eq('id', userId)
          .select()
          .single();

        if (error) throw error;

        await supabase.from('admin_actions').insert({
          admin_id: 'system',
          user_id: userId,
          action_type: 'block',
          details: 'User blocked by admin',
          created_at: new Date().toISOString()
        });

        return res.status(200).json({ success: true, user });
      }

      if (action === 'unblockUser') {
        const { data: user, error } = await supabase
          .from('users')
          .update({ is_blocked: false })
          .eq('id', userId)
          .select()
          .single();

        if (error) throw error;

        await supabase.from('admin_actions').insert({
          admin_id: 'system',
          user_id: userId,
          action_type: 'unblock',
          details: 'User unblocked by admin',
          created_at: new Date().toISOString()
        });

        return res.status(200).json({ success: true, user });
      }

      if (action === 'updateBalance') {
        const { balanceType, amount } = data;
        const updateData = {};
        updateData[balanceType] = amount;

        const { data: user, error } = await supabase
          .from('users')
          .update(updateData)
          .eq('id', userId)
          .select()
          .single();

        if (error) throw error;

        await supabase.from('admin_actions').insert({
          admin_id: 'system',
          user_id: userId,
          action_type: 'balance_update',
          details: `Updated ${balanceType} to ${amount}`,
          created_at: new Date().toISOString()
        });

        return res.status(200).json({ success: true, user });
      }

      if (action === 'getTransactions') {
        const { data: transactions, error } = await supabase
          .from('transactions')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(100);

        if (error) throw error;
        return res.status(200).json(transactions);
      }
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Admin API error:', err);
    res.status(500).json({ error: err.message });
  }
}