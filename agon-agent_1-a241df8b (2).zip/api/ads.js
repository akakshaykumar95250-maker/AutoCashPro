import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { userId } = req.body;

      // Get user data
      const { data: user, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (userError || !user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if blocked
      if (user.is_blocked) {
        return res.status(403).json({ error: 'Account blocked' });
      }

      // Check daily limit (1500 ads)
      if (user.ads_today >= 1500) {
        return res.status(429).json({ error: 'Daily limit reached. Come back tomorrow!' });
      }

      // Check 5-min break after 50 ads
      if (user.ads_today > 0 && user.ads_today % 50 === 0) {
        const lastAdTime = new Date(user.last_ad_time);
        const now = new Date();
        const minutesSinceLastAd = (now - lastAdTime) / (1000 * 60);
        
        if (minutesSinceLastAd < 5) {
          const waitTime = Math.ceil(5 - minutesSinceLastAd);
          return res.status(429).json({ 
            error: `Take a break! Wait ${waitTime} minutes before continuing.`,
            break_time: waitTime
          });
        }
      }

      // Check rate limiting (min 3 seconds between ads)
      if (user.last_ad_time) {
        const lastAdTime = new Date(user.last_ad_time);
        const now = new Date();
        const secondsSinceLastAd = (now - lastAdTime) / 1000;
        
        if (secondsSinceLastAd < 3) {
          return res.status(429).json({ error: 'Please wait before watching another ad' });
        }
      }

      // Award coins (10 coins per ad)
      const coinsEarned = 10;
      const newCoins = user.coins + coinsEarned;
      const newAdsToday = user.ads_today + 1;

      // Update user
      const { data: updatedUser, error: updateError } = await supabase
        .from('users')
        .update({
          coins: newCoins,
          locked_balance: user.locked_balance + coinsEarned,
          ads_today: newAdsToday,
          last_ad_time: new Date().toISOString()
        })
        .eq('id', userId)
        .select()
        .single();

      if (updateError) throw updateError;

      // Record transaction
      await supabase.from('transactions').insert({
        user_id: userId,
        type: 'ad_reward',
        amount: coinsEarned,
        from_balance: null,
        to_balance: 'locked',
        description: `Ad watched - ${coinsEarned} coins earned`,
        created_at: new Date().toISOString()
      });

      return res.status(200).json({
        success: true,
        coinsEarned,
        newCoins: updatedUser.coins,
        newLockedBalance: updatedUser.locked_balance,
        adsToday: updatedUser.ads_today,
        dailyLimit: 1500
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Ads API error:', err);
    res.status(500).json({ error: err.message });
  }
}