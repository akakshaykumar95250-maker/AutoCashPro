import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { email, password, action } = req.body;

      if (action === 'signup') {
        const { data: existingUser } = await supabase
          .from('users')
          .select('id')
          .eq('email', email)
          .single();

        if (existingUser) {
          return res.status(400).json({ error: 'Email already registered' });
        }

        const { data, error } = await supabase
          .from('users')
          .insert({
            email,
            password_hash: password, // In production, hash this!
            coins: 0,
            locked_balance: 0,
            main_wallet: 0,
            ads_today: 0,
            last_ad_time: null,
            last_sync_time: new Date().toISOString(),
            created_at: new Date().toISOString()
          })
          .select()
          .single();

        if (error) throw error;
        return res.status(201).json(data);
      }

      if (action === 'login') {
        const { data, error } = await supabase
          .from('users')
          .select('*')
          .eq('email', email)
          .eq('password_hash', password)
          .single();

        if (error || !data) {
          return res.status(401).json({ error: 'Invalid credentials' });
        }

        if (data.is_blocked) {
          return res.status(403).json({ error: 'Account blocked. Contact admin.' });
        }

        return res.status(200).json(data);
      }

      if (action === 'guest') {
        const { data, error } = await supabase
          .from('users')
          .insert({
            email: `guest_${Date.now()}@autocash.pro`,
            password_hash: 'guest_access',
            coins: 100,
            locked_balance: 0,
            main_wallet: 50,
            ads_today: 0,
            last_ad_time: null,
            last_sync_time: new Date().toISOString(),
            is_guest: true,
            created_at: new Date().toISOString()
          })
          .select()
          .single();

        if (error) throw error;
        return res.status(201).json(data);
      }
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Auth API error:', err);
    res.status(500).json({ error: err.message });
  }
}