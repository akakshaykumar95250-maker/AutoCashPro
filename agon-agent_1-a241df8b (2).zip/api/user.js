import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { userId } = req.query;

      // Get user data
      const { data: user, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (userError || !user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Get user transactions
      const { data: transactions, error: transError } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (transError) throw transError;

      // Calculate sync status
      const lastSync = new Date(user.last_sync_time);
      const now = new Date();
      const hoursSinceSync = (now - lastSync) / (1000 * 60 * 60);
      const canSync = hoursSinceSync >= 24;
      const hoursRemaining = canSync ? 0 : Math.ceil(24 - hoursSinceSync);

      return res.status(200).json({
        user,
        transactions,
        syncStatus: {
          canSync,
          hoursRemaining,
          lastSync: user.last_sync_time
        }
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('User API error:', err);
    res.status(500).json({ error: err.message });
  }
}