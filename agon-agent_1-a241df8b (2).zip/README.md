# AutoCash Pro - Android Earning App

A premium Android earning app built with Expo React Native, Firebase, and AdMob.

## 🚀 Features

- **Firebase Authentication**: Email/Password login + Guest Access
- **AdMob Rewarded Ads**: Strict `onUserEarnedReward` callback implementation
- **Earning System**: 10 coins per ad, 40% revenue sync after 24h
- **Wallet System**: Main Wallet + Locked Balance
- **UPI Withdrawals**: Direct withdrawal to UPI ID
- **Admin Panel**: Manage users, balances, and blocks
- **Cyberpunk UI**: Premium dark theme with neon accents

## 📋 Prerequisites

1. **Node.js** (v18 or higher)
2. **Expo CLI**
   ```bash
   npm install -g expo-cli
   ```
3. **EAS CLI** (for building APK)
   ```bash
   npm install -g eas-cli
   ```
4. **Firebase Project** configured
5. **AdMob Account** with ad units created

## 🔧 Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Firebase

Update `firebase.js` with your Firebase config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### 3. Configure AdMob

Update `screens/DashboardScreen.tsx` with your Ad Unit IDs:

```typescript
const REWARDED_AD_UNIT_ID = __DEV__
  ? TestIds.REWARDED
  : 'ca-app-pub-YOUR_REWARDED_AD_UNIT_ID';
```

### 4. Update app.json

Ensure your `app.json` has correct package name and AdMob config:

```json
{
  "expo": {
    "android": {
      "package": "com.sahil.autocashpro"
    },
    "plugins": [
      [
        "expo-ads-admob",
        {
          "androidAppId": "ca-app-pub-YOUR_ANDROID_APP_ID"
        }
      ]
    ]
  }
}
```

## 🏃 Running the App

### Development Mode

```bash
# Start Expo dev server
expo start
```

Then scan the QR code with Expo Go app on your phone.

### iOS Simulator
```bash
expo run:ios
```

### Android Emulator
```bash
expo run:android
```

## 📦 Building APK with EAS

### Step 1: Login to EAS

```bash
eas login
```

### Step 2: Configure EAS Project

```bash
eas build:configure
```

### Step 3: Build APK (Development)

```bash
eas build --platform android --profile development
```

### Step 4: Build APK (Production)

```bash
eas build --platform android --profile production
```

### Step 5: Build APK (Preview/Internal)

```bash
eas build --platform android --profile preview
```

## 📱 AdMob Integration

The app uses `react-native-google-mobile-ads` with strict reward logic:

1. **Ad Loading**: Rewarded ad loads on component mount
2. **Ad Playing**: User watches full ad
3. **onUserEarnedReward**: Callback fires ONLY when ad completes
4. **Coins Awarded**: API call happens AFTER callback
5. **Early Close**: If user closes early, NO coins awarded

## 🔐 Admin Access

- Navigate to Admin panel from Dashboard settings
- Secret Key: **CYBER2077**
- Features: Block/unblock users, update balances, view transactions

## 💰 Earning Logic

- **1 Ad = 10 Coins**
- **Daily Limit**: 1500 ads
- **40% Revenue Sync**: After 24 hours, 40% of locked balance transfers to main wallet
- **Conversion**: 1000 Coins = ₹1 INR
- **Minimum Withdrawal**: 1000 coins (₹1)

## 📊 Firebase Firestore Structure

### Users Collection
```javascript
{
  email: string,
  coins: number,
  locked_balance: number,
  main_wallet: number,
  ads_today: number,
  last_ad_time: timestamp,
  last_sync_time: timestamp,
  is_blocked: boolean,
  is_guest: boolean,
  created_at: timestamp
}
```

### Transactions Collection
```javascript
{
  user_id: string,
  type: 'ad_reward' | 'sync' | 'withdrawal',
  amount: number,
  from_balance: string | null,
  to_balance: string | null,
  description: string,
  created_at: timestamp
}
```

## 🎨 UI Theme

- **Background**: Dark gradient (gray-900 → blue-950)
- **Accents**: Neon Cyan (#22d3ee) and Gold (#fbbf24)
- **Style**: Cyberpunk with glass-morphism effects

## 📄 License

This project is for educational purposes.

## ⚠️ Important Notes

1. **AdMob Policy**: Follow Google's ad placement policies
2. **Firebase Rules**: Set proper Firestore security rules
3. **App Store**: Follow Google Play Store guidelines
4. **User Data**: Implement proper privacy policy

## 🆘 Troubleshooting

### AdMob Ads Not Showing
- Ensure AdMob app is properly linked
- Check ad unit IDs are correct
- Use test IDs in development

### Firebase Connection Issues
- Verify Firebase config in `firebase.js`
- Check Firestore rules allow read/write
- Ensure internet connection

### Build Failures
- Clear Expo cache: `expo start -c`
- Reinstall dependencies: `rm -rf node_modules && npm install`
- Check EAS CLI version: `eas --version`
