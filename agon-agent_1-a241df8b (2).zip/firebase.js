// Firebase Configuration
import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAuth, getAuth, getReactNativePersistence } from 'firebase/auth';
import { initializeFirestore, getFirestore } from 'firebase/firestore';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

// Your Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCeSiHEKwlkDmXkJynNM57NPMA7xtUa7T4",
  authDomain: "autocash-pro-28f68.firebaseapp.com",
  projectId: "autocash-pro-28f68",
  storageBucket: "autocash-pro-28f68.firebasestorage.app",
  messagingSenderId: "123456789",
  appId: "1:123456789:android:abcdef123456"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth with AsyncStorage persistence
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});

// Initialize Firestore
const db = initializeFirestore(app, {
  cacheSizeBytes: 10485760 // 10MB cache
});

export { app, auth, db };