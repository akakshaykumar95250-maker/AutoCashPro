import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Coins, Wallet, TrendingUp, Shield, Zap, LogOut, Settings, History, ArrowUpRight, RefreshCw, Play, Pause, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface DashboardProps {
  user: any;
  onLogout: () => void;
  setUser: (user: any) => void;
}

export default function Dashboard({ user, onLogout, setUser }: DashboardProps) {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(user);
  const [transactions, setTransactions] = useState([]);
  const [syncStatus, setSyncStatus] = useState({ canSync: false, hoursRemaining: 0 });
  const [loading, setLoading] = useState(false);
  
  // AdMob Rewarded Ad States
  const [adState, setAdState] = useState<'idle' | 'loading' | 'playing' | 'rewarded' | 'closed_early'>('idle');
  const [adProgress, setAdProgress] = useState(0);
  const [canCloseAd, setCanCloseAd] = useState(false);
  const [adReward, setAdReward] = useState<{ earned: boolean; amount: number } | null>(null);
  
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [upiId, setUpiId] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });

  const fetchUserData = async () => {
    try {
      const res = await fetch(`/api/user?userId=${userData.id}`);
      const data = await res.json();
      if (res.ok) {
        setUserData(data.user);
        setTransactions(data.transactions);
        setSyncStatus(data.syncStatus);
        setUser(data.user);
        localStorage.setItem('autocash_user', JSON.stringify(data.user));
      }
    } catch (err) {
      console.error('Fetch error:', err);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  // AdMob Rewarded Ad Simulation
  const loadAndShowRewardedAd = async () => {
    // Step 1: Set loading state (simulating ad loading)
    setAdState('loading');
    setAdProgress(0);
    setCanCloseAd(false);
    setAdReward(null);
    setMessage({ type: '', text: '' });

    // Simulate ad loading delay (1 second)
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Step 2: Start playing the ad
    setAdState('playing');

    // Simulate ad duration (5 seconds)
    const adDuration = 5000;
    const interval = 50; // Update every 50ms
    const steps = adDuration / interval;
    let currentStep = 0;

    const progressInterval = setInterval(() => {
      currentStep++;
      const progress = (currentStep / steps) * 100;
      setAdProgress(progress);

      // Step 3: Ad completed - trigger onUserEarnedReward callback
      if (currentStep >= steps) {
        clearInterval(progressInterval);
        
        // This is the CRITICAL onUserEarnedReward callback
        // Coins are ONLY credited here when the ad finishes completely
        const onUserEarnedReward = async () => {
          // Award coins via API
          try {
            const res = await fetch('/api/ads', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: userData.id }),
            });

            const data = await res.json();

            if (res.ok) {
              setAdReward({ earned: true, amount: data.coinsEarned });
              setAdState('rewarded');
              setCanCloseAd(true);
              await fetchUserData();
            } else {
              setAdReward({ earned: false, amount: 0 });
              setAdState('closed_early');
              setCanCloseAd(true);
              setMessage({ type: 'error', text: data.error || 'Failed to award reward' });
            }
          } catch (err: any) {
            setAdReward({ earned: false, amount: 0 });
            setAdState('closed_early');
            setCanCloseAd(true);
            setMessage({ type: 'error', text: err.message });
          }
        };

        // Execute the reward callback
        onUserEarnedReward();
      }
    }, interval);

    return () => clearInterval(progressInterval);
  };

  const handleCloseAd = () => {
    if (!canCloseAd) {
      // User tried to close before ad finished
      setMessage({ type: 'error', text: 'Ad not finished. No coins earned.' });
      return;
    }

    // Ad finished or user closed after reward
    if (adReward?.earned) {
      setMessage({ type: 'success', text: `+${adReward.amount} coins earned!` });
    } else {
      setMessage({ type: 'error', text: 'Ad not finished. No coins earned.' });
    }

    // Reset ad state after showing result
    setTimeout(() => {
      setAdState('idle');
      setAdProgress(0);
      setAdReward(null);
      setCanCloseAd(false);
    }, 2000);
  };

  const handleSync = async () => {
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const res = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userData.id }),
      });

      const data = await res.json();

      if (!res.ok) {
        setMessage({ type: 'error', text: data.error || 'Sync failed' });
      } else {
        setMessage({ type: 'success', text: data.message });
        await fetchUserData();
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseInt(withdrawAmount);
    if (!amount || amount < 1000) {
      setMessage({ type: 'error', text: 'Minimum withdrawal is 1000 coins' });
      return;
    }
    if (!upiId) {
      setMessage({ type: 'error', text: 'Please enter UPI ID' });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userData.id, amount, upiId }),
      });

      const data = await res.json();

      if (!res.ok) {
        setMessage({ type: 'error', text: data.error || 'Withdrawal failed' });
      } else {
        setMessage({ type: 'success', text: data.message });
        setWithdrawAmount('');
        setUpiId('');
        setShowWithdrawModal(false);
        await fetchUserData();
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-950 to-gray-900">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-lg mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">AutoCash Pro</h1>
            <p className="text-sm text-gray-400">Welcome back!</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/admin')}
              className="p-2 bg-gray-800/50 rounded-lg text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={onLogout}
              className="p-2 bg-gray-800/50 rounded-lg text-gray-400 hover:text-red-400 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Balance Cards */}
        <div className="space-y-4 mb-6">
          {/* Main Wallet */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-amber-500/20 to-orange-600/20 backdrop-blur-xl border border-amber-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-amber-400" />
                <span className="text-amber-400 font-medium">Main Wallet</span>
              </div>
              <RefreshCw 
                className={`w-4 h-4 text-amber-400 cursor-pointer ${loading ? 'animate-spin' : ''}`} 
                onClick={fetchUserData}
              />
            </div>
            <div className="flex items-baseline gap-2">
              <motion.span
                key={userData.main_wallet}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-4xl font-bold text-white"
              >
                {userData.main_wallet.toLocaleString()}
              </motion.span>
              <span className="text-amber-400">coins</span>
            </div>
            <div className="mt-2 text-sm text-gray-400">
              ≈ ₹{(userData.main_wallet / 1000).toFixed(2)} INR
            </div>
          </motion.div>

          {/* Locked Balance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-cyan-500/20 to-blue-600/20 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-cyan-400" />
                <span className="text-cyan-400 font-medium">Locked Balance</span>
              </div>
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="flex items-baseline gap-2">
              <motion.span
                key={userData.locked_balance}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-3xl font-bold text-white"
              >
                {userData.locked_balance.toLocaleString()}
              </motion.span>
              <span className="text-cyan-400">coins</span>
            </div>
            <div className="mt-2 text-sm text-gray-400">
              {syncStatus.canSync ? (
                <span className="text-green-400">Ready to sync!</span>
              ) : (
                <span>Sync in {syncStatus.hoursRemaining}h</span>
              )}
            </div>
          </motion.div>
        </div>

        {/* Sync Button */}
        <motion.button
          onClick={handleSync}
          disabled={!syncStatus.canSync || loading}
          whileHover={syncStatus.canSync ? { scale: 1.02 } : {}}
          whileTap={syncStatus.canSync ? { scale: 0.98 } : {}}
          className={`w-full mb-6 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
            syncStatus.canSync 
              ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white shadow-lg shadow-green-500/25' 
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Syncing...' : syncStatus.canSync ? 'Sync Revenue (40%)' : `Wait ${syncStatus.hoursRemaining}h to sync`}
        </motion.button>

        {/* Watch Ad Button */}
        <motion.button
          onClick={loadAndShowRewardedAd}
          disabled={adState !== 'idle'}
          whileHover={adState === 'idle' ? { scale: 1.02 } : {}}
          whileTap={adState === 'idle' ? { scale: 0.98 } : {}}
          className="w-full mb-6 py-8 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 hover:from-cyan-400 hover:via-blue-400 hover:to-purple-500 text-white font-bold text-xl rounded-2xl transition-all duration-300 shadow-2xl shadow-cyan-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex flex-col items-center justify-center gap-3"
        >
          {adState === 'loading' ? (
            <>
              <div className="w-12 h-12 border-4 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Loading Ad...</span>
            </>
          ) : adState === 'playing' || adState === 'rewarded' ? (
            <>
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Pause className="w-6 h-6" />
              </div>
              <span>Ad Playing...</span>
            </>
          ) : (
            <>
              <Play className="w-12 h-12" />
              <div className="flex items-center gap-2">
                <Zap className="w-6 h-6" />
                <span>Watch Ad & Earn +10 Coins</span>
              </div>
            </>
          )}
        </motion.button>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-gray-400">Today's Ads</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {userData.ads_today} <span className="text-sm text-gray-500">/ 1500</span>
            </div>
            <div className="mt-2 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-500"
                style={{ width: `${(userData.ads_today / 1500) * 100}%` }}
              />
            </div>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Coins className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-gray-400">Total Earned</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {(userData.main_wallet + userData.locked_balance).toLocaleString()}
            </div>
            <div className="mt-2 text-sm text-gray-400">
              ≈ ₹{((userData.main_wallet + userData.locked_balance) / 1000).toFixed(2)}
            </div>
          </div>
        </div>

        {/* Withdraw Button */}
        <motion.button
          onClick={() => setShowWithdrawModal(true)}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full mb-6 py-4 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-green-500/25 flex items-center justify-center gap-2"
        >
          <ArrowUpRight className="w-5 h-5" />
          Withdraw to UPI
        </motion.button>

        {/* Transaction History */}
        <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-purple-400" />
              <span className="font-semibold text-white">Recent Activity</span>
            </div>
          </div>
          
          <div className="space-y-3">
            {transactions.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No transactions yet</p>
            ) : (
              transactions.slice(0, 5).map((tx: any) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      tx.type === 'ad_reward' ? 'bg-green-500/20' : 
                      tx.type === 'sync' ? 'bg-blue-500/20' : 
                      tx.type === 'withdrawal' ? 'bg-purple-500/20' : 'bg-gray-500/20'
                    }`}>
                      {tx.type === 'ad_reward' && <Zap className="w-5 h-5 text-green-400" />}
                      {tx.type === 'sync' && <RefreshCw className="w-5 h-5 text-blue-400" />}
                      {tx.type === 'withdrawal' && <ArrowUpRight className="w-5 h-5 text-purple-400" />}
                    </div>
                    <div>
                      <p className="text-sm text-white font-medium">{tx.description}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(tx.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <span className={`font-semibold ${
                    tx.type === 'ad_reward' || tx.type === 'sync' ? 'text-green-400' : 'text-purple-400'
                  }`}>
                    {tx.type === 'withdrawal' ? '-' : '+'}{tx.amount}
                  </span>
                </motion.div>
              ))
            )}
          </div>
        </div>

        {/* Message Display */}
        <AnimatePresence>
          {message.text && adState === 'idle' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`fixed bottom-4 left-4 right-4 max-w-lg mx-auto p-4 rounded-xl backdrop-blur-xl border ${
                message.type === 'success' 
                  ? 'bg-green-500/20 border-green-500/30 text-green-400' 
                  : 'bg-red-500/20 border-red-500/30 text-red-400'
              }`}
            >
              {message.text}
            </motion.div>
          )}
        </AnimatePresence>

        {/* AdMob Rewarded Ad Modal */}
        <AnimatePresence>
          {adState !== 'idle' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-gray-900 border border-cyan-500/30 rounded-2xl p-8 max-w-md w-full text-center relative"
              >
                {/* Close Button */}
                <button
                  onClick={handleCloseAd}
                  disabled={!canCloseAd}
                  className={`absolute top-4 right-4 p-2 rounded-full transition-all ${
                    canCloseAd 
                      ? 'bg-gray-700 hover:bg-gray-600 text-white cursor-pointer' 
                      : 'bg-gray-800 text-gray-600 cursor-not-allowed opacity-50'
                  }`}
                  title={canCloseAd ? 'Close' : 'Wait for ad to finish'}
                >
                  <X className="w-5 h-5" />
                </button>

                {adState === 'loading' && (
                  <>
                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center">
                      <div className="w-10 h-10 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Loading Ad...</h3>
                    <p className="text-gray-400">Please wait while the ad loads</p>
                  </>
                )}

                {adState === 'playing' && (
                  <>
                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center animate-pulse">
                      <Play className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Ad Playing...</h3>
                    <p className="text-gray-400 mb-6">Watch the full ad to earn rewards</p>
                    
                    {/* Ad Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-gray-400 mb-2">
                        <span>Ad Progress</span>
                        <span>{Math.round(adProgress)}%</span>
                      </div>
                      <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-cyan-400 to-blue-500"
                          initial={{ width: '0%' }}
                          animate={{ width: `${adProgress}%` }}
                          transition={{ duration: 0.05 }}
                        />
                      </div>
                    </div>

                    {!canCloseAd && (
                      <p className="text-sm text-amber-400 flex items-center justify-center gap-2">
                        <Zap className="w-4 h-4" />
                        Wait for ad to finish to earn coins
                      </p>
                    )}
                  </>
                )}

                {adState === 'rewarded' && adReward?.earned && (
                  <>
                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center">
                      <Zap className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-green-400 mb-2">Reward Earned!</h3>
                    <p className="text-3xl font-bold text-white mb-2">+{adReward.amount} Coins</p>
                    <p className="text-gray-400">Ad completed successfully</p>
                    <p className="text-sm text-green-400 mt-4">Close to continue</p>
                  </>
                )}

                {adState === 'closed_early' && (
                  <>
                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-red-500 to-orange-600 rounded-2xl flex items-center justify-center">
                      <Pause className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-red-400 mb-2">Ad Not Finished</h3>
                    <p className="text-white mb-2">No coins earned</p>
                    <p className="text-gray-400 text-sm">You must watch the full ad to earn rewards</p>
                  </>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Withdraw Modal */}
        <AnimatePresence>
          {showWithdrawModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-gray-900 border border-green-500/30 rounded-2xl p-6 max-w-sm w-full"
              >
                <h3 className="text-xl font-bold text-white mb-4">Withdraw to UPI</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Amount (coins)</label>
                    <input
                      type="number"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      min="1000"
                      max={userData.main_wallet}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-green-400"
                      placeholder="Min 1000 coins"
                    />
                    <p className="text-xs text-gray-500 mt-1">Available: {userData.main_wallet.toLocaleString()} coins</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">UPI ID</label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-green-400"
                      placeholder="yourname@upi"
                    />
                  </div>

                  <div className="bg-gray-800/50 rounded-lg p-3">
                    <p className="text-sm text-gray-400">You will receive:</p>
                    <p className="text-lg font-bold text-green-400">
                      ₹{withdrawAmount ? (parseInt(withdrawAmount) / 1000).toFixed(2) : '0.00'}
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowWithdrawModal(false)}
                      className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleWithdraw}
                      disabled={loading || !withdrawAmount || !upiId}
                      className="flex-1 py-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Processing...' : 'Withdraw'}
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}