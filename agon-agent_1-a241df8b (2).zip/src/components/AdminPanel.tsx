import { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, Ban, Edit3, ArrowLeft, Lock, Unlock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AdminPanel() {
  const navigate = useNavigate();
  const [isVerified, setIsVerified] = useState(false);
  const [secretKey, setSecretKey] = useState('');
  const [users, setUsers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [activeTab, setActiveTab] = useState<'users' | 'transactions'>('users');
  const [editingUser, setEditingUser] = useState<any>(null);
  const [editForm, setEditForm] = useState({ coins: 0, locked_balance: 0, main_wallet: 0 });
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleVerify = async () => {
    if (secretKey !== 'CYBER2077') {
      setMessage({ type: 'error', text: 'Invalid secret key' });
      return;
    }
    setIsVerified(true);
    fetchData();
  };

  const fetchData = async () => {
    try {
      const [usersRes, transRes] = await Promise.all([
        fetch('/api/admin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ secretKey, action: 'getUsers' }),
        }),
        fetch('/api/admin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ secretKey, action: 'getTransactions' }),
        }),
      ]);

      const usersData = await usersRes.json();
      const transData = await transRes.json();

      if (usersRes.ok) setUsers(usersData);
      if (transRes.ok) setTransactions(transData);
    } catch (err) {
      console.error('Fetch error:', err);
    }
  };

  const handleBlockUser = async (userId: string) => {
    try {
      const res = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ secretKey, action: 'blockUser', userId }),
      });
      if (res.ok) {
        setMessage({ type: 'success', text: 'User blocked successfully' });
        fetchData();
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to block user' });
    }
  };

  const handleUnblockUser = async (userId: string) => {
    try {
      const res = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ secretKey, action: 'unblockUser', userId }),
      });
      if (res.ok) {
        setMessage({ type: 'success', text: 'User unblocked successfully' });
        fetchData();
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to unblock user' });
    }
  };

  const handleUpdateBalance = async () => {
    if (!editingUser) return;
    try {
      const res = await fetch('/api/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          secretKey,
          action: 'updateBalance',
          userId: editingUser.id,
          balanceType: 'coins',
          amount: editForm.coins
        }),
      });
      if (res.ok) {
        setMessage({ type: 'success', text: 'Balance updated successfully' });
        setEditingUser(null);
        fetchData();
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to update balance' });
    }
  };

  const openEditModal = (user: any) => {
    setEditingUser(user);
    setEditForm({
      coins: user.coins,
      locked_balance: user.locked_balance,
      main_wallet: user.main_wallet
    });
  };

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-950 to-gray-900 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>

          <div className="bg-gray-900/80 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 mx-auto bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mb-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
              <p className="text-gray-400 mt-2">Enter secret key to continue</p>
            </div>

            <div className="space-y-4">
              <input
                type="password"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleVerify()}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:outline-none focus:border-purple-400"
                placeholder="Enter secret key"
              />

              {message.text && (
                <div className={`p-3 rounded-lg ${
                  message.type === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                }`}>
                  {message.text}
                </div>
              )}

              <button
                onClick={handleVerify}
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white font-semibold rounded-xl transition-all"
              >
                Verify
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-950 to-gray-900">
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 bg-gray-800/50 rounded-lg text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
              <p className="text-sm text-gray-400">Manage users and transactions</p>
            </div>
          </div>
          <button
            onClick={fetchData}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg transition-colors"
          >
            Refresh
          </button>
        </div>

        {/* Message */}
        {message.text && (
          <div className={`mb-4 p-3 rounded-lg ${
            message.type === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
          }`}>
            {message.text}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Total Users', value: users.length, icon: Users, color: 'cyan' },
            { label: 'Blocked Users', value: users.filter((u: any) => u.is_blocked).length, icon: Ban, color: 'red' },
            { label: 'Total Coins', value: users.reduce((acc: number, u: any) => acc + u.coins + u.locked_balance + u.main_wallet, 0).toLocaleString(), icon: Shield, color: 'amber' },
            { label: 'Transactions', value: transactions.length, icon: Edit3, color: 'purple' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`bg-${stat.color}-500/20 backdrop-blur-xl border border-${stat.color}-500/30 rounded-xl p-4`}
            >
              <stat.icon className={`w-5 h-5 text-${stat.color}-400 mb-2`} />
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'users' 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            Users
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'transactions' 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            Transactions
          </button>
        </div>

        {/* Content */}
        {activeTab === 'users' ? (
          <div className="bg-gray-900/80 backdrop-blur-xl border border-gray-700 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-800">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Email</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Coins</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Locked</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Main Wallet</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Ads Today</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {users.map((u: any) => (
                    <tr key={u.id} className="hover:bg-gray-800/50">
                      <td className="px-4 py-3 text-sm text-white">{u.email}</td>
                      <td className="px-4 py-3 text-sm text-cyan-400">{u.coins.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-amber-400">{u.locked_balance.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-green-400">{u.main_wallet.toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm text-purple-400">{u.ads_today}</td>
                      <td className="px-4 py-3">
                        {u.is_blocked ? (
                          <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full">Blocked</span>
                        ) : (
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">Active</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => openEditModal(u)}
                            className="p-1 text-gray-400 hover:text-cyan-400 transition-colors"
                            title="Edit Balance"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          {u.is_blocked ? (
                            <button
                              onClick={() => handleUnblockUser(u.id)}
                              className="p-1 text-gray-400 hover:text-green-400 transition-colors"
                              title="Unblock"
                            >
                              <Unlock className="w-4 h-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleBlockUser(u.id)}
                              className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                              title="Block"
                            >
                              <Lock className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-gray-900/80 backdrop-blur-xl border border-gray-700 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-800">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Type</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Amount</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Description</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {transactions.map((tx: any) => (
                    <tr key={tx.id} className="hover:bg-gray-800/50">
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          tx.type === 'ad_reward' ? 'bg-green-500/20 text-green-400' :
                          tx.type === 'sync' ? 'bg-blue-500/20 text-blue-400' :
                          tx.type === 'withdrawal' ? 'bg-purple-500/20 text-purple-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {tx.type}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-white">{tx.amount}</td>
                      <td className="px-4 py-3 text-sm text-gray-400">{tx.description}</td>
                      <td className="px-4 py-3 text-sm text-gray-400">{new Date(tx.created_at).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Edit Modal */}
        {editingUser && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-gray-900 border border-cyan-500/30 rounded-2xl p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-bold text-white mb-4">Edit User Balance</h3>
              <p className="text-sm text-gray-400 mb-4">{editingUser.email}</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Coins</label>
                  <input
                    type="number"
                    value={editForm.coins}
                    onChange={(e) => setEditForm({ ...editForm, coins: parseInt(e.target.value) })}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setEditingUser(null)}
                    className="flex-1 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpdateBalance}
                    className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl"
                  >
                    Save
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}