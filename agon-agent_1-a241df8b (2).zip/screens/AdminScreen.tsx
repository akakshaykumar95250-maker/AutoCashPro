import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { doc, updateDoc, getDocs, collection, query, orderBy } from 'firebase/firestore';
import { auth, db } from '../firebase';

interface Props {
  navigation: any;
  route: any;
}

export default function AdminScreen({ navigation, route }: Props) {
  const [isVerified, setIsVerified] = useState(false);
  const [secretKey, setSecretKey] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'users' | 'transactions'>('users');
  const [editingUser, setEditingUser] = useState<any>(null);
  const [editCoins, setEditCoins] = useState('');

  const fetchData = async () => {
    try {
      // Fetch all users
      const usersQuery = query(collection(db, 'users'), orderBy('created_at', 'desc'));
      const usersSnapshot = await getDocs(usersQuery);
      const usersList = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(usersList);

      // Fetch all transactions
      const txQuery = query(collection(db, 'transactions'), orderBy('created_at', 'desc'));
      const txSnapshot = await getDocs(txQuery);
      const txList = txSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTransactions(txList);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleVerify = () => {
    if (secretKey === 'CYBER2077') {
      setIsVerified(true);
      fetchData();
    } else {
      Alert.alert('Error', 'Invalid secret key');
    }
  };

  const handleBlockUser = async (userId: string, isBlocked: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        is_blocked: isBlocked
      });
      Alert.alert('Success', isBlocked ? 'User blocked' : 'User unblocked');
      fetchData();
    } catch (error) {
      Alert.alert('Error', 'Failed to update user');
    }
  };

  const handleUpdateBalance = async () => {
    if (!editingUser || !editCoins) return;
    try {
      await updateDoc(doc(db, 'users', editingUser.id), {
        coins: parseInt(editCoins)
      });
      Alert.alert('Success', 'Balance updated');
      setEditingUser(null);
      setEditCoins('');
      fetchData();
    } catch (error) {
      Alert.alert('Error', 'Failed to update balance');
    }
  };

  if (!isVerified) {
    return (
      <ScrollView style={styles.container}>
        <LinearGradient
          colors={['#0f172a', '#1e3a5f', '#0f172a']}
          style={StyleSheet.absoluteFillObject}
        />

        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-back" size={24} color="#9ca3af" />
          <Text style={styles.backText}>Back to Dashboard</Text>
        </TouchableOpacity>

        <View style={styles.centerContainer}>
          <View style={styles.iconContainer}>
            <Ionicons name="shield" size={40} color="#a855f7" />
          </View>
          <Text style={styles.title}>Admin Panel</Text>
          <Text style={styles.subtitle}>Enter secret key to continue</Text>

          <TextInput
            style={styles.input}
            placeholder="Enter secret key"
            placeholderTextColor="#6b7280"
            value={secretKey}
            onChangeText={setSecretKey}
            secureTextEntry
            onSubmitEditing={handleVerify}
          />

          <TouchableOpacity style={styles.button} onPress={handleVerify}>
            <Text style={styles.buttonText}>Verify</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <LinearGradient
        colors={['#0f172a', '#1e3a5f', '#0f172a']}
        style={StyleSheet.absoluteFillObject}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#9ca3af" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>Admin Panel</Text>
          <Text style={styles.headerSubtitle}>Manage users and transactions</Text>
        </View>
        <TouchableOpacity onPress={fetchData}>
          <Ionicons name="refresh" size={24} color="#9ca3af" />
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <Ionicons name="people" size={24} color="#22d3ee" />
          <Text style={styles.statValue}>{users.length}</Text>
          <Text style={styles.statLabel}>Total Users</Text>
        </View>
        <View style={styles.statCard}>
          <Ionicons name="ban" size={24} color="#ef4444" />
          <Text style={styles.statValue}>{users.filter((u: any) => u.is_blocked).length}</Text>
          <Text style={styles.statLabel}>Blocked</Text>
        </View>
        <View style={styles.statCard}>
          <Ionicons name="cash" size={24} color="#fbbf24" />
          <Text style={styles.statValue}>{users.reduce((acc: number, u: any) => acc + (u.coins || 0) + (u.locked_balance || 0) + (u.main_wallet || 0), 0).toLocaleString()}</Text>
          <Text style={styles.statLabel}>Total Coins</Text>
        </View>
        <View style={styles.statCard}>
          <Ionicons name="list" size={24} color="#a855f7" />
          <Text style={styles.statValue}>{transactions.length}</Text>
          <Text style={styles.statLabel}>Transactions</Text>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'users' && styles.activeTab]}
          onPress={() => setActiveTab('users')}
        >
          <Text style={[styles.tabText, activeTab === 'users' && styles.activeTabText]}>Users</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tab, activeTab === 'transactions' && styles.activeTab]}
          onPress={() => setActiveTab('transactions')}
        >
          <Text style={[styles.tabText, activeTab === 'transactions' && styles.activeTabText]}>Transactions</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      {activeTab === 'users' ? (
        <View style={styles.listContainer}>
          {users.map((user: any) => (
            <View key={user.id} style={styles.listItem}>
              <View style={styles.itemInfo}>
                <Text style={styles.itemTitle}>{user.email}</Text>
                <Text style={styles.itemSub}>Coins: {user.coins?.toLocaleString()} | Locked: {user.locked_balance?.toLocaleString()} | Wallet: {user.main_wallet?.toLocaleString()}</Text>
                <Text style={styles.itemSub}>Ads Today: {user.ads_today}</Text>
              </View>
              <View style={styles.itemActions}>
                <TouchableOpacity onPress={() => { setEditingUser(user); setEditCoins(user.coins?.toString() || '0'); }}>
                  <Ionicons name="create" size={20} color="#22d3ee" />
                </TouchableOpacity>
                {user.is_blocked ? (
                  <TouchableOpacity onPress={() => handleBlockUser(user.id, false)}>
                    <Ionicons name="lock-open" size={20} color="#22c55e" />
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity onPress={() => handleBlockUser(user.id, true)}>
                    <Ionicons name="lock" size={20} color="#ef4444" />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.listContainer}>
          {transactions.map((tx: any) => (
            <View key={tx.id} style={styles.listItem}>
              <View style={styles.itemInfo}>
                <Text style={styles.itemTitle}>{tx.description}</Text>
                <Text style={styles.itemSub}>{new Date(tx.created_at).toLocaleString()}</Text>
              </View>
              <Text style={[styles.itemAmount, tx.type === 'withdrawal' ? styles.withdrawalAmount : styles.earnAmount]}>
                {tx.type === 'withdrawal' ? '-' : '+'}{tx.amount}
              </Text>
            </View>
          ))}
        </View>
      )}

      {/* Edit User Modal */}
      <Modal
        visible={!!editingUser}
        transparent
        animationType="fade"
        onRequestClose={() => setEditingUser(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit User Balance</Text>
            <Text style={styles.modalSubtitle}>{editingUser?.email}</Text>
            
            <Text style={styles.label}>Coins</Text>
            <TextInput
              style={styles.input}
              value={editCoins}
              onChangeText={setEditCoins}
              keyboardType="numeric"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setEditingUser(null)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleUpdateBalance}
              >
                <Text style={styles.modalButtonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    gap: 8,
  },
  backText: {
    color: '#9ca3af',
    fontSize: 16,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 20,
    backgroundColor: 'rgba(168, 85, 247, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#9ca3af',
    marginBottom: 32,
  },
  input: {
    width: '100%',
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#fff',
    borderWidth: 1,
    borderColor: '#374151',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#a855f7',
    paddingVertical: 16,
    paddingHorizontal: 48,
    borderRadius: 12,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#9ca3af',
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    width: '48%',
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 4,
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 16,
    gap: 8,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: '#1f2937',
    borderRadius: 8,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#a855f7',
  },
  tabText: {
    color: '#9ca3af',
    fontSize: 14,
    fontWeight: '500',
  },
  activeTabText: {
    color: '#fff',
  },
  listContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  listItem: {
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
  },
  itemInfo: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  itemSub: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 2,
  },
  itemActions: {
    flexDirection: 'row',
    gap: 16,
  },
  itemAmount: {
    fontSize: 14,
    fontWeight: '600',
  },
  earnAmount: {
    color: '#22c55e',
  },
  withdrawalAmount: {
    color: '#a855f7',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#111827',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 320,
    borderWidth: 1,
    borderColor: 'rgba(34, 211, 238, 0.3)',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#9ca3af',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#9ca3af',
    marginBottom: 8,
    marginTop: 8,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#374151',
  },
  confirmButton: {
    backgroundColor: '#22d3ee',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});