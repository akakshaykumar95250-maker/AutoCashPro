import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Modal,
  Alert,
  ActivityIndicator
} from 'react-native';
import { LinearGradient } from 'react-native-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { signOut as firebaseSignOut } from 'firebase/auth';
import { doc, getDoc, updateDoc, addDoc, collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { auth, db } from '../firebase';
import RewardedAd, {
  TestIds,
  RewardedAdEventType,
} from 'react-native-google-mobile-ads';

// AdMob Ad Unit IDs
const REWARDED_AD_UNIT_ID = __DEV__
  ? TestIds.REWARDED
  : 'ca-app-pub-2899978770';

// Create rewarded ad instance
const rewardedAd = RewardedAd.createForAdRequest(REWARDED_AD_UNIT_ID, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

interface Props {
  navigation: any;
  route: any;
}

export default function DashboardScreen({ navigation, route }: Props) {
  const user = auth.currentUser;
  const [userData, setUserData] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Ad States
  const [adState, setAdState] = useState<'idle' | 'loading' | 'playing' | 'rewarded' | 'error'>('idle');
  const [adMessage, setAdMessage] = useState('');
  const [showAdModal, setShowAdModal] = useState(false);
  const [adProgress, setAdProgress] = useState(0);
  
  // Withdraw Modal
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [upiId, setUpiId] = useState('');

  const fetchUserData = async () => {
    if (!user) return;
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        setUserData(userDoc.data());
      }

      // Fetch transactions
      const q = query(
        collection(db, 'transactions'),
        where('user_id', '==', user.uid),
        orderBy('created_at', 'desc'),
        limit(10)
      );
      const querySnapshot = await getDocs(q);
      const txs = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTransactions(txs);
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  useEffect(() => {
    fetchUserData();

    // Load rewarded ad
    const unsubscribeLoaded = rewardedAd.addAdEventListener(RewardedAdEventType.LOADED, () => {
      console.log('Rewarded ad loaded');
    });

    const unsubscribeError = rewardedAd.addAdEventListener(RewardedAdEventType.ERROR, (error) => {
      console.error('Rewarded ad error:', error);
      setAdState('error');
      setAdMessage('Failed to load ad. Please try again.');
    });

    // CRITICAL: onUserEarnedReward callback
    const unsubscribeEarned = rewardedAd.addAdEventListener(
      RewardedAdEventType.EARNED_REWARD,
      (reward) => {
        console.log('User earned reward:', reward);
        handleRewardEarned(reward.amount, reward.type);
      }
    );

    const unsubscribeClosed = rewardedAd.addAdEventListener(
      RewardedAdEventType.CLOSED,
      () => {
        console.log('Ad closed');
        if (adState !== 'rewarded') {
          // User closed before earning reward
          setAdState('error');
          setAdMessage('Ad not finished. No coins earned.');
        }
        setTimeout(() => {
          setShowAdModal(false);
          setAdState('idle');
        }, 2000);
      }
    );

    // Start loading the ad
    rewardedAd.load();

    return () => {
      unsubscribeLoaded();
      unsubscribeError();
      unsubscribeEarned();
      unsubscribeClosed();
    };
  }, [user]);

  const handleRewardEarned = async (amount: number, type: string) => {
    console.log('Reward earned! Amount:', amount, 'Type:', type);
    setAdState('rewarded');
    setAdMessage(`+10 coins earned!`);

    try {
      // Check daily limit and rate limiting
      if (userData && userData.ads_today >= 1500) {
        setAdMessage('Daily limit reached!');
        return;
      }

      // Award coins
      const coinsEarned = 10;
      const newCoins = (userData?.coins || 0) + coinsEarned;
      const newLocked = (userData?.locked_balance || 0) + coinsEarned;
      const newAdsToday = (userData?.ads_today || 0) + 1;

      await updateDoc(doc(db, 'users', user!.uid), {
        coins: newCoins,
        locked_balance: newLocked,
        ads_today: newAdsToday,
        last_ad_time: new Date().toISOString()
      });

      // Record transaction
      await addDoc(collection(db, 'transactions'), {
        user_id: user!.uid,
        type: 'ad_reward',
        amount: coinsEarned,
        from_balance: null,
        to_balance: 'locked',
        description: `Ad watched - ${coinsEarned} coins earned`,
        created_at: new Date().toISOString()
      });

      await fetchUserData();
    } catch (error) {
      console.error('Error awarding reward:', error);
      setAdMessage('Failed to award coins. Please try again.');
    }
  };

  const handleWatchAd = async () => {
    if (!rewardedAd.loaded) {
      Alert.alert('Loading', 'Please wait while the ad loads...');
      return;
    }

    setAdState('loading');
    setShowAdModal(true);
    setAdMessage('');
    setAdProgress(0);

    try {
      await rewardedAd.show();
      setAdState('playing');
      
      // Simulate progress
      const progressInterval = setInterval(() => {
        setAdProgress(prev => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            return 100;
          }
          return prev + 2;
        });
      }, 100);
    } catch (error) {
      console.error('Error showing ad:', error);
      setAdState('error');
      setAdMessage('Failed to show ad. Please try again.');
    }
  };

  const handleSync = async () => {
    if (!userData) return;
    
    const lastSync = new Date(userData.last_sync_time);
    const now = new Date();
    const hoursSinceSync = (now.getTime() - lastSync.getTime()) / (1000 * 60 * 60);

    if (hoursSinceSync < 24) {
      const hoursRemaining = Math.ceil(24 - hoursSinceSync);
      Alert.alert('Wait', `Wait ${hoursRemaining} hours before next sync`);
      return;
    }

    setLoading(true);
    try {
      const transferAmount = Math.floor(userData.locked_balance * 0.40);
      if (transferAmount > 0) {
        await updateDoc(doc(db, 'users', user!.uid), {
          locked_balance: userData.locked_balance - transferAmount,
          main_wallet: userData.main_wallet + transferAmount,
          last_sync_time: new Date().toISOString()
        });

        await addDoc(collection(db, 'transactions'), {
          user_id: user!.uid,
          type: 'sync',
          amount: transferAmount,
          from_balance: 'locked',
          to_balance: 'main',
          description: `Revenue sync - 40% transferred (${transferAmount} coins)`,
          created_at: new Date().toISOString()
        });

        Alert.alert('Success', `Transferred ${transferAmount} coins to main wallet!`);
        await fetchUserData();
      } else {
        Alert.alert('Info', 'No eligible balance to transfer');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to sync revenue');
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseInt(withdrawAmount);
    if (!amount || amount < 1000) {
      Alert.alert('Error', 'Minimum withdrawal is 1000 coins');
      return;
    }
    if (!upiId) {
      Alert.alert('Error', 'Please enter UPI ID');
      return;
    }

    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user!.uid), {
        main_wallet: userData.main_wallet - amount
      });

      await addDoc(collection(db, 'transactions'), {
        user_id: user!.uid,
        type: 'withdrawal',
        amount: amount,
        from_balance: 'main',
        to_balance: null,
        description: `Withdrawal request - ${amount} coins to UPI: ${upiId}`,
        created_at: new Date().toISOString()
      });

      Alert.alert('Success', `Withdrawal of ₹${(amount / 1000).toFixed(2)} submitted!`);
      setShowWithdrawModal(false);
      setWithdrawAmount('');
      setUpiId('');
      await fetchUserData();
    } catch (error) {
      Alert.alert('Error', 'Failed to process withdrawal');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (!userData) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#22d3ee" />
      </View>
    );
  }

  const hoursRemaining = Math.max(0, 24 - (new Date().getTime() - new Date(userData.last_sync_time).getTime()) / (1000 * 60 * 60));
  const canSync = hoursRemaining <= 0;

  return (
    <ScrollView style={styles.container}>
      {/* Background Gradient */}
      <LinearGradient
        colors={['#0f172a', '#1e3a5f', '#0f172a']}
        style={StyleSheet.absoluteFillObject}
      />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>AutoCash Pro</Text>
          <Text style={styles.headerSubtitle}>Welcome back!</Text>
        </View>
        <View style={styles.headerButtons}>
          <TouchableOpacity onPress={() => navigation.navigate('Admin')}>
            <Ionicons name="settings" size={24} color="#9ca3af" />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogout}>
            <Ionicons name="log-out" size={24} color="#9ca3af" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Main Wallet Card */}
      <LinearGradient
        colors={['rgba(245, 158, 11, 0.2)', 'rgba(234, 88, 12, 0.2)']}
        style={[styles.card, styles.walletCard]}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardTitle}>
            <Ionicons name="wallet" size={20} color="#fbbf24" />
            <Text style={[styles.cardTitleText, { color: '#fbbf24' }]}>Main Wallet</Text>
          </View>
          <TouchableOpacity onPress={fetchUserData}>
            <Ionicons name="refresh" size={18} color="#fbbf24" />
          </TouchableOpacity>
        </View>
        <Text style={styles.balanceText}>{userData.main_wallet.toLocaleString()}</Text>
        <Text style={styles.balanceSubtext}>≈ ₹{(userData.main_wallet / 1000).toFixed(2)} INR</Text>
      </LinearGradient>

      {/* Locked Balance Card */}
      <LinearGradient
        colors={['rgba(34, 211, 238, 0.2)', 'rgba(59, 130, 246, 0.2)']}
        style={[styles.card, styles.lockedCard]}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardTitle}>
            <Ionicons name="shield" size={20} color="#22d3ee" />
            <Text style={[styles.cardTitleText, { color: '#22d3ee' }]}>Locked Balance</Text>
          </View>
          <Ionicons name="trending-up" size={18} color="#22d3ee" />
        </View>
        <Text style={styles.balanceText}>{userData.locked_balance.toLocaleString()}</Text>
        <Text style={styles.balanceSubtext}>
          {canSync ? 'Ready to sync!' : `Sync in ${Math.ceil(hoursRemaining)}h`}
        </Text>
      </LinearGradient>

      {/* Sync Button */}
      <TouchableOpacity
        style={[styles.button, canSync ? styles.syncButton : styles.disabledButton]}
        onPress={handleSync}
        disabled={!canSync || loading}
      >
        <Ionicons name="refresh" size={20} color={canSync ? '#fff' : '#6b7280'} />
        <Text style={[styles.buttonText, { color: canSync ? '#fff' : '#6b7280' }]}>
          {loading ? 'Syncing...' : canSync ? 'Sync Revenue (40%)' : `Wait ${Math.ceil(hoursRemaining)}h to sync`}
        </Text>
      </TouchableOpacity>

      {/* Watch Ad Button */}
      <TouchableOpacity
        style={styles.watchAdButton}
        onPress={handleWatchAd}
        disabled={adState !== 'idle'}
      >
        {adState === 'loading' ? (
          <ActivityIndicator size="large" color="#fff" />
        ) : adState === 'playing' ? (
          <Ionicons name="pause" size={40} color="#fff" />
        ) : (
          <Ionicons name="play" size={40} color="#fff" />
        )}
        <Text style={styles.watchAdText}>
          {adState === 'loading' ? 'Loading Ad...' : 
           adState === 'playing' ? 'Ad Playing...' : 
           'Watch Ad & Earn +10 Coins'}
        </Text>
      </TouchableOpacity>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={styles.statHeader}>
            <Ionicons name="flash" size={18} color="#fbbf24" />
            <Text style={styles.statLabel}>Today's Ads</Text>
          </View>
          <Text style={styles.statValue}>{userData.ads_today} <Text style={styles.statSub}>/ 1500</Text></Text>
          <View style={styles.progressBar}>
            <View 
              style={[styles.progressFill, { width: `${(userData.ads_today / 1500) * 100}%` }]}
            />
          </View>
        </View>

        <View style={styles.statCard}>
          <View style={styles.statHeader}>
            <Ionicons name="cash" size={18} color="#22d3ee" />
            <Text style={styles.statLabel}>Total Earned</Text>
          </View>
          <Text style={styles.statValue}>{(userData.main_wallet + userData.locked_balance).toLocaleString()}</Text>
          <Text style={styles.statSub}>≈ ₹{((userData.main_wallet + userData.locked_balance) / 1000).toFixed(2)}</Text>
        </View>
      </View>

      {/* Withdraw Button */}
      <TouchableOpacity
        style={[styles.button, styles.withdrawButton]}
        onPress={() => setShowWithdrawModal(true)}
      >
        <Ionicons name="arrow-up" size={20} color="#fff" />
        <Text style={styles.buttonText}>Withdraw to UPI</Text>
      </TouchableOpacity>

      {/* Transaction History */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={styles.cardTitle}>
            <Ionicons name="list" size={20} color="#a855f7" />
            <Text style={[styles.cardTitleText, { color: '#a855f7' }]}>Recent Activity</Text>
          </View>
        </View>
        {transactions.length === 0 ? (
          <Text style={styles.emptyText}>No transactions yet</Text>
        ) : (
          transactions.slice(0, 5).map((tx: any) => (
            <View key={tx.id} style={styles.transactionItem}>
              <View style={styles.transactionIcon}>
                {tx.type === 'ad_reward' && <Ionicons name="flash" size={20} color="#22c55e" />}
                {tx.type === 'sync' && <Ionicons name="refresh" size={20} color="#3b82f6" />}
                {tx.type === 'withdrawal' && <Ionicons name="arrow-up" size={20} color="#a855f7" />}
              </View>
              <View style={styles.transactionInfo}>
                <Text style={styles.transactionDesc}>{tx.description}</Text>
                <Text style={styles.transactionDate}>{new Date(tx.created_at).toLocaleDateString()}</Text>
              </View>
              <Text style={[styles.transactionAmount, tx.type === 'withdrawal' ? styles.withdrawalAmount : styles.earnAmount]}>
                {tx.type === 'withdrawal' ? '-' : '+'}{tx.amount}
              </Text>
            </View>
          ))
        )}
      </View>

      {/* Ad Modal */}
      <Modal
        visible={showAdModal}
        transparent
        animationType="fade"
        onRequestClose={() => {}}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {adState === 'loading' && (
              <>
                <ActivityIndicator size="large" color="#22d3ee" />
                <Text style={styles.modalTitle}>Loading Ad...</Text>
              </>
            )}
            {adState === 'playing' && (
              <>
                <Ionicons name="play" size={60} color="#22d3ee" />
                <Text style={styles.modalTitle}>Ad Playing...</Text>
                <Text style={styles.modalSubtitle}>Watch full ad to earn rewards</Text>
                <View style={styles.modalProgress}>
                  <View style={[styles.modalProgressFill, { width: `${adProgress}%` }]} />
                </View>
                <Text style={styles.modalNote}>Wait for ad to finish to earn coins</Text>
              </>
            )}
            {adState === 'rewarded' && (
              <>
                <Ionicons name="flash" size={60} color="#22c55e" />
                <Text style={[styles.modalTitle, { color: '#22c55e' }]}>Reward Earned!</Text>
                <Text style={styles.modalReward}>+10 Coins</Text>
                <Text style={styles.modalSubtitle}>Ad completed successfully</Text>
              </>
            )}
            {adState === 'error' && (
              <>
                <Ionicons name="close-circle" size={60} color="#ef4444" />
                <Text style={[styles.modalTitle, { color: '#ef4444' }]}>Error</Text>
                <Text style={styles.modalSubtitle}>{adMessage}</Text>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Withdraw Modal */}
      <Modal
        visible={showWithdrawModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowWithdrawModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Withdraw to UPI</Text>
            
            <Text style={styles.label}>Amount (coins)</Text>
            <TextInput
              style={styles.input}
              placeholder="Min 1000 coins"
              placeholderTextColor="#6b7280"
              value={withdrawAmount}
              onChangeText={setWithdrawAmount}
              keyboardType="numeric"
            />
            <Text style={styles.inputNote}>Available: {userData.main_wallet.toLocaleString()} coins</Text>

            <Text style={styles.label}>UPI ID</Text>
            <TextInput
              style={styles.input}
              placeholder="yourname@upi"
              placeholderTextColor="#6b7280"
              value={upiId}
              onChangeText={setUpiId}
            />

            <View style={styles.previewBox}>
              <Text style={styles.previewLabel}>You will receive:</Text>
              <Text style={styles.previewAmount}>₹{withdrawAmount ? (parseInt(withdrawAmount) / 1000).toFixed(2) : '0.00'}</Text>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowWithdrawModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleWithdraw}
                disabled={loading}
              >
                <Text style={styles.modalButtonText}>{loading ? 'Processing...' : 'Withdraw'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#9ca3af',
    marginTop: 4,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  card: {
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(34, 211, 238, 0.2)',
  },
  walletCard: {
    marginTop: 20,
    borderWidth: 1,
    borderColor: 'rgba(251, 191, 36, 0.3)',
  },
  lockedCard: {
    borderWidth: 1,
    borderColor: 'rgba(34, 211, 238, 0.3)',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardTitleText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#22d3ee',
  },
  balanceText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#fff',
  },
  balanceSubtext: {
    fontSize: 14,
    color: '#9ca3af',
    marginTop: 4,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 20,
    marginBottom: 16,
    gap: 8,
  },
  syncButton: {
    backgroundColor: '#22c55e',
  },
  disabledButton: {
    backgroundColor: '#374151',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  watchAdButton: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    marginHorizontal: 20,
    marginBottom: 16,
    borderRadius: 16,
    backgroundColor: 'linear-gradient(90deg, #22d3ee, #3b82f6, #a855f7)',
  },
  watchAdText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#374151',
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#9ca3af',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  statSub: {
    fontSize: 12,
    color: '#6b7280',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#374151',
    borderRadius: 4,
    overflow: 'hidden',
    marginTop: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: 'linear-gradient(90deg, #fbbf24, #f97316)',
  },
  withdrawButton: {
    backgroundColor: '#22c55e',
  },
  emptyText: {
    textAlign: 'center',
    color: '#6b7280',
    padding: 32,
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  transactionInfo: {
    flex: 1,
  },
  transactionDesc: {
    fontSize: 14,
    color: '#fff',
    marginBottom: 2,
  },
  transactionDate: {
    fontSize: 12,
    color: '#6b7280',
  },
  transactionAmount: {
    fontSize: 14,
    fontWeight: '600',
  },
  earnAmount: {
    color: '#22c55e',
  },
  withdrawalAmount: {
    color: '#a855f7',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#111827',
    borderRadius: 20,
    padding: 32,
    width: '100%',
    maxWidth: 320,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(34, 211, 238, 0.3)',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 16,
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#9ca3af',
    textAlign: 'center',
  },
  modalReward: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#22c55e',
    marginVertical: 8,
  },
  modalProgress: {
    width: '100%',
    height: 8,
    backgroundColor: '#374151',
    borderRadius: 4,
    overflow: 'hidden',
    marginVertical: 16,
  },
  modalProgressFill: {
    height: '100%',
    backgroundColor: '#22d3ee',
  },
  modalNote: {
    fontSize: 12,
    color: '#fbbf24',
    marginTop: 12,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#9ca3af',
    marginBottom: 8,
    marginTop: 16,
  },
  input: {
    width: '100%',
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#fff',
    borderWidth: 1,
    borderColor: '#374151',
  },
  inputNote: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
  },
  previewBox: {
    width: '100%',
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  previewLabel: {
    fontSize: 14,
    color: '#9ca3af',
  },
  previewAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#22c55e',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    marginTop: 24,
  },
  modalButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#374151',
  },
  confirmButton: {
    backgroundColor: '#22c55e',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});